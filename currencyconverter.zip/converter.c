/*****************
Name : Pritesh suryawanshi
Date : 10/7/2024
Description : currency converter

Sample input :  1. Convert INR to USD
                2. Convert USD to INR
               21. Exit

                   

Sample output :   Enter your choice: 1
                  Enter amount: 100
                  100 INR = 1.2 USD

******************/

#include "converter.h"
#include <string.h>

// Example exchange rates (rates are illustrative and should be updated to current rates)
#define INR_TO_USD 0.012
#define INR_TO_EUR 0.010
#define INR_TO_JPY 1.45
#define INR_TO_RUB 0.011

#define USD_TO_INR 83.30
#define EUR_TO_INR 83.40
#define JPY_TO_INR 0.69
#define RUB_TO_INR 92.43

// Convert amount from one currency to another
float convertCurrency(float amount, float exchangeRate) {
    return amount * exchangeRate;
}

// Get exchange rate between two currencies
float getExchangeRate(const char* fromCurrency, const char* toCurrency) {
    if (strcmp(fromCurrency, "INR") == 0 && strcmp(toCurrency, "USD") == 0) return INR_TO_USD;
    if (strcmp(fromCurrency, "USD") == 0 && strcmp(toCurrency, "INR") == 0) return USD_TO_INR;
    if (strcmp(fromCurrency, "INR") == 0 && strcmp(toCurrency, "EUR") == 0) return INR_TO_EUR;
    if (strcmp(fromCurrency, "EUR") == 0 && strcmp(toCurrency, "INR") == 0) return EUR_TO_INR;
    if (strcmp(fromCurrency, "INR") == 0 && strcmp(toCurrency, "JPY") == 0) return INR_TO_JPY;
    if (strcmp(fromCurrency, "JPY") == 0 && strcmp(toCurrency, "INR") == 0) return JPY_TO_INR;
    if (strcmp(fromCurrency, "INR") == 0 && strcmp(toCurrency, "RUB") == 0) return INR_TO_RUB;
    if (strcmp(fromCurrency, "RUB") == 0 && strcmp(toCurrency, "INR") == 0) return RUB_TO_INR;

    // If conversion involves two non-INR currencies, use INR as an intermediary
    if (strcmp(fromCurrency, "USD") == 0 && strcmp(toCurrency, "EUR") == 0) return USD_TO_INR * INR_TO_EUR;
    if (strcmp(fromCurrency, "USD") == 0 && strcmp(toCurrency, "JPY") == 0) return USD_TO_INR * INR_TO_JPY;
    if (strcmp(fromCurrency, "USD") == 0 && strcmp(toCurrency, "RUB") == 0) return USD_TO_INR * INR_TO_RUB;
    if (strcmp(fromCurrency, "EUR") == 0 && strcmp(toCurrency, "USD") == 0) return EUR_TO_INR * INR_TO_USD;
    if (strcmp(fromCurrency, "EUR") == 0 && strcmp(toCurrency, "JPY") == 0) return EUR_TO_INR * INR_TO_JPY;
    if (strcmp(fromCurrency, "EUR") == 0 && strcmp(toCurrency, "RUB") == 0) return EUR_TO_INR * INR_TO_RUB;
    if (strcmp(fromCurrency, "JPY") == 0 && strcmp(toCurrency, "USD") == 0) return JPY_TO_INR * INR_TO_USD;
    if (strcmp(fromCurrency, "JPY") == 0 && strcmp(toCurrency, "EUR") == 0) return JPY_TO_INR * INR_TO_EUR;
    if (strcmp(fromCurrency, "JPY") == 0 && strcmp(toCurrency, "RUB") == 0) return JPY_TO_INR * INR_TO_RUB;
    if (strcmp(fromCurrency, "RUB") == 0 && strcmp(toCurrency, "USD") == 0) return RUB_TO_INR * INR_TO_USD;
    if (strcmp(fromCurrency, "RUB") == 0 && strcmp(toCurrency, "EUR") == 0) return RUB_TO_INR * INR_TO_EUR;
    if (strcmp(fromCurrency, "RUB") == 0 && strcmp(toCurrency, "JPY") == 0) return RUB_TO_INR * INR_TO_JPY;

    return 0.0; // Return 0 if no valid exchange rate is found
}

