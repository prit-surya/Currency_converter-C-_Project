#ifndef CONVERTER_H
#define CONVERTER_H

#ifdef __cplusplus
extern "C" {
#endif

// Convert amount from one currency to another using exchange rate
float convertCurrency(float amount, float exchangeRate);

// Get exchange rate between two currencies
float getExchangeRate(const char* fromCurrency, const char* toCurrency);

#ifdef __cplusplus
}
#endif

#endif // CONVERTER_H

