#include <iostream>
#include "converter.h"

// Function to display the menu and get the user's choice
void displayMenu() {
    std::cout << "\nCurrency Converter\n";
    std::cout << "1. Convert INR to USD\n";
    std::cout << "2. Convert USD to INR\n";
    std::cout << "3. Convert INR to EUR\n";
    std::cout << "4. Convert EUR to INR\n";
    std::cout << "5. Convert INR to JPY\n";
    std::cout << "6. Convert JPY to INR\n";
    std::cout << "7. Convert INR to RUB\n";
    std::cout << "8. Convert RUB to INR\n";
    std::cout << "9. Convert USD to EUR\n";
    std::cout << "10. Convert EUR to USD\n";
    std::cout << "11. Convert USD to JPY\n";
    std::cout << "12. Convert JPY to USD\n";
    std::cout << "13. Convert USD to RUB\n";
    std::cout << "14. Convert RUB to USD\n";
    std::cout << "15. Convert EUR to JPY\n";
    std::cout << "16. Convert JPY to EUR\n";
    std::cout << "17. Convert EUR to RUB\n";
    std::cout << "18. Convert RUB to EUR\n";
    std::cout << "19. Convert JPY to RUB\n";
    std::cout << "20. Convert RUB to JPY\n";
    std::cout << "21. Exit\n";
}

// Function to convert currencies based on user choice
void convertCurrencies(int choice) {
    const char* fromCurrency;
    const char* toCurrency;
    float exchangeRate, amount, result;

    switch (choice) {
        case 1:
            fromCurrency = "INR";
            toCurrency = "USD";
            break;
        case 2:
            fromCurrency = "USD";
            toCurrency = "INR";
            break;
        case 3:
            fromCurrency = "INR";
            toCurrency = "EUR";
            break;
        case 4:
            fromCurrency = "EUR";
            toCurrency = "INR";
            break;
        case 5:
            fromCurrency = "INR";
            toCurrency = "JPY";
            break;
        case 6:
            fromCurrency = "JPY";
            toCurrency = "INR";
            break;
        case 7:
            fromCurrency = "INR";
            toCurrency = "RUB";
            break;
        case 8:
            fromCurrency = "RUB";
            toCurrency = "INR";
            break;
        case 9:
            fromCurrency = "USD";
            toCurrency = "EUR";
            break;
        case 10:
            fromCurrency = "EUR";
            toCurrency = "USD";
            break;
        case 11:
            fromCurrency = "USD";
            toCurrency = "JPY";
            break;
        case 12:
            fromCurrency = "JPY";
            toCurrency = "USD";
            break;
        case 13:
            fromCurrency = "USD";
            toCurrency = "RUB";
            break;
        case 14:
            fromCurrency = "RUB";
            toCurrency = "USD";
            break;
        case 15:
            fromCurrency = "EUR";
            toCurrency = "JPY";
            break;
        case 16:
            fromCurrency = "JPY";
            toCurrency = "EUR";
            break;
        case 17:
            fromCurrency = "EUR";
            toCurrency = "RUB";
            break;
        case 18:
            fromCurrency = "RUB";
            toCurrency = "EUR";
            break;
        case 19:
            fromCurrency = "JPY";
            toCurrency = "RUB";
            break;
        case 20:
            fromCurrency = "RUB";
            toCurrency = "JPY";
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
            return;
    }

    // Get the exchange rate for the selected conversion type
    exchangeRate = getExchangeRate(fromCurrency, toCurrency);

    if (exchangeRate == 0.0) {
        std::cout << "Exchange rate not found.\n";
        return;
    }

    // Prompt the user for the amount to convert
    std::cout << "Enter amount: ";
    std::cin >> amount;

    // Perform the conversion
    result = convertCurrency(amount, exchangeRate);

    // Format and display the result
    std::cout << amount << " " << fromCurrency << " = " << result << " " << toCurrency << "\n";
}

int main() {
    int choice; // Variable to store the user's choice

    // Loop to keep the program running until the user chooses to exit
    while (true) {
        displayMenu(); // Display the menu
        std::cout << "Enter your choice: ";
        std::cin >> choice; // Read user input
        if (choice == 21) break; // Exit the loop if the user chooses to exit

        convertCurrencies(choice); // Convert currencies based on the user's choice
    }

    std::cout << "Exiting program...\n";
    return 0; // Exit the program
}

